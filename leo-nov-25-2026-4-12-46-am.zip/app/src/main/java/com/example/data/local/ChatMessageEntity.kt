package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val messageType: String,
    val content: String,
    val routingOption: String,
    val fileUrl: String? = null,
    val fileName: String? = null,
    val fileMimeType: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
)
