package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.RoutingOption
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.leoDataStore: DataStore<Preferences> by preferencesDataStore(name = "leo_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val WEBHOOK_URL = stringPreferencesKey("webhook_url")
        val SELECTED_ROUTING = stringPreferencesKey("selected_routing")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
    }

    val webhookUrl: Flow<String> = context.leoDataStore.data.map { prefs ->
        prefs[Keys.WEBHOOK_URL] ?: ""
    }

    val selectedRouting: Flow<RoutingOption> = context.leoDataStore.data.map { prefs ->
        RoutingOption.fromLabel(prefs[Keys.SELECTED_ROUTING] ?: RoutingOption.GENERAL.label)
    }

    val autoSpeakEnabled: Flow<Boolean> = context.leoDataStore.data.map { prefs ->
        prefs[Keys.AUTO_SPEAK] ?: true
    }

    val speechRate: Flow<Float> = context.leoDataStore.data.map { prefs ->
        (prefs[Keys.SPEECH_RATE] ?: 1.05f).coerceIn(0.75f, 1.5f)
    }

    suspend fun setWebhookUrl(url: String) {
        context.leoDataStore.edit { prefs ->
            prefs[Keys.WEBHOOK_URL] = url.trim()
        }
    }

    suspend fun setSelectedRouting(option: RoutingOption) {
        context.leoDataStore.edit { prefs ->
            prefs[Keys.SELECTED_ROUTING] = option.label
        }
    }

    suspend fun setAutoSpeakEnabled(enabled: Boolean) {
        context.leoDataStore.edit { prefs ->
            prefs[Keys.AUTO_SPEAK] = enabled
        }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.leoDataStore.edit { prefs ->
            prefs[Keys.SPEECH_RATE] = rate.coerceIn(0.75f, 1.5f)
        }
    }
}
