package com.example.data.remote

import com.example.data.model.WebhookRequestPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class WebhookClient {

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val payloadAdapter = moshi.adapter(WebhookRequestPayload::class.java)
    private val anyAdapter = moshi.adapter(Any::class.java)
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun postPayload(
        webhookUrl: String,
        payload: WebhookRequestPayload,
    ): Result<String> = withContext(Dispatchers.IO) {
        val cleanUrl = webhookUrl.trim()
        if (!cleanUrl.startsWith("http://", ignoreCase = true) &&
            !cleanUrl.startsWith("https://", ignoreCase = true)
        ) {
            return@withContext Result.failure(
                IllegalArgumentException("Invalid webhook URL. It must start with http:// or https://")
            )
        }

        val jsonBody = payloadAdapter.toJson(payload)
        val requestBody = jsonBody.toRequestBody(jsonMediaType)

        val request = try {
            Request.Builder()
                .url(cleanUrl)
                .post(requestBody)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .build()
        } catch (e: IllegalArgumentException) {
            return@withContext Result.failure(
                IllegalArgumentException("Malformed webhook URL: ${e.localizedMessage}")
            )
        }

        try {
            okHttpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = extractTextFromResponse(rawBody).takeIf { it.isNotBlank() }
                        ?: response.message
                    return@withContext Result.failure(
                        IOException("Webhook returned HTTP ${response.code}: $detail")
                    )
                }

                val parsedText = extractTextFromResponse(rawBody)
                if (parsedText.isBlank()) {
                    return@withContext Result.failure(
                        IOException("Webhook responded with HTTP ${response.code} but returned an empty body.")
                    )
                }
                Result.success(parsedText)
            }
        } catch (e: Exception) {
            Result.failure(IOException("Network error: ${e.localizedMessage ?: "Unable to reach webhook"}", e))
        }
    }

    internal fun extractTextFromResponse(rawBody: String): String {
        val trimmed = rawBody.trim()
        if (trimmed.isEmpty()) return ""

        return try {
            when (val parsed = anyAdapter.fromJson(trimmed)) {
                is Map<*, *> -> extractFromMap(parsed).ifBlank { trimmed }
                is List<*> -> extractFromList(parsed).ifBlank { trimmed }
                is String -> parsed
                null -> trimmed
                else -> parsed.toString()
            }
        } catch (_: Exception) {
            trimmed
        }
    }

    private fun extractFromMap(map: Map<*, *>): String {
        val preferredKeys = listOf(
            "response",
            "reply",
            "text",
            "message",
            "output",
            "content",
            "answer",
            "leo_response",
            "result",
            "body",
        )
        for (key in preferredKeys) {
            val value = map[key]
            when (value) {
                is String -> if (value.isNotBlank()) return value
                is Map<*, *> -> {
                    val nested = extractFromMap(value)
                    if (nested.isNotBlank()) return nested
                }
                is List<*> -> {
                    val nested = extractFromList(value)
                    if (nested.isNotBlank()) return nested
                }
            }
        }

        val dataObj = map["data"]
        if (dataObj is Map<*, *>) {
            val nested = extractFromMap(dataObj)
            if (nested.isNotBlank()) return nested
        }

        for (value in map.values) {
            if (value is String && value.isNotBlank()) {
                return value
            }
        }
        return ""
    }

    private fun extractFromList(list: List<*>): String {
        if (list.isEmpty()) return ""
        return when (val first = list.first()) {
            is Map<*, *> -> extractFromMap(first)
            is String -> first
            else -> ""
        }
    }
}
