package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.example.data.local.ChatMessageDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.SettingsDataStore
import com.example.data.model.MessageSender
import com.example.data.model.MessageType
import com.example.data.model.PreparedFileAttachment
import com.example.data.model.RoutingOption
import com.example.data.model.WebhookRequestPayload
import com.example.data.remote.WebhookClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class LeoRepository(
    private val context: Context,
    private val chatMessageDao: ChatMessageDao,
    private val settingsDataStore: SettingsDataStore,
    private val webhookClient: WebhookClient = WebhookClient(),
) {

    val messages: Flow<List<ChatMessageEntity>> = chatMessageDao.observeAllMessages()
    val webhookUrl: Flow<String> = settingsDataStore.webhookUrl
    val selectedRouting: Flow<RoutingOption> = settingsDataStore.selectedRouting
    val autoSpeakEnabled: Flow<Boolean> = settingsDataStore.autoSpeakEnabled
    val speechRate: Flow<Float> = settingsDataStore.speechRate

    suspend fun saveWebhookUrl(url: String) = settingsDataStore.setWebhookUrl(url)
    suspend fun saveSelectedRouting(option: RoutingOption) = settingsDataStore.setSelectedRouting(option)
    suspend fun saveAutoSpeakEnabled(enabled: Boolean) = settingsDataStore.setAutoSpeakEnabled(enabled)
    suspend fun saveSpeechRate(rate: Float) = settingsDataStore.setSpeechRate(rate)
    suspend fun clearChatHistory() = withContext(Dispatchers.IO) {
        chatMessageDao.clearAllMessages()
        File(context.filesDir, "attachments").deleteRecursively()
    }

    suspend fun deleteMessageById(id: Long) = chatMessageDao.deleteMessageById(id)

    suspend fun insertMessage(
        sender: MessageSender,
        messageType: MessageType,
        content: String,
        routingOption: RoutingOption,
        fileUrl: String? = null,
        fileName: String? = null,
        fileMimeType: String? = null,
        isError: Boolean = false,
    ): Long {
        return chatMessageDao.insertMessage(
            ChatMessageEntity(
                sender = sender.name,
                messageType = messageType.wireValue,
                content = content,
                routingOption = routingOption.label,
                fileUrl = fileUrl,
                fileName = fileName,
                fileMimeType = fileMimeType,
                timestamp = System.currentTimeMillis(),
                isError = isError,
            )
        )
    }

    suspend fun dispatchToWebhook(
        webhookUrl: String,
        messageType: MessageType,
        content: String,
        routingOption: RoutingOption,
        fileUrl: String? = null,
    ): Result<String> {
        val payload = WebhookRequestPayload(
            messageType = messageType.wireValue,
            content = content,
            dropdownSelection = routingOption.label,
            fileUrl = fileUrl,
        )
        return webhookClient.postPayload(webhookUrl = webhookUrl, payload = payload)
    }

    suspend fun prepareFileAttachment(uri: Uri): PreparedFileAttachment = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"
        var fileName = "attachment"
        var fileSize = -1L

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) {
                    cursor.getString(nameIndex)?.let { fileName = it }
                }
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                    fileSize = cursor.getLong(sizeIndex)
                }
            }
        }

        // Persist a copy in app cache for reliable local thumbnail/preview display across restarts
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val localDir = File(context.filesDir, "attachments").apply { mkdirs() }
        val localFile = File(localDir, "${System.currentTimeMillis()}_$safeName")

        var copiedBytes: ByteArray? = null
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val maxDataUrlBytes = 2L * 1024L * 1024L // 2 MB cap for inline base64 data URL
                if (fileSize in 0..maxDataUrlBytes) {
                    val bytes = input.readBytes()
                    localFile.writeBytes(bytes)
                    if (bytes.size <= maxDataUrlBytes) {
                        copiedBytes = bytes
                    }
                    fileSize = bytes.size.toLong()
                } else {
                    localFile.outputStream().use { out ->
                        input.copyTo(out)
                    }
                    fileSize = localFile.length()
                    if (fileSize <= maxDataUrlBytes) {
                        copiedBytes = localFile.readBytes()
                    }
                }
            }
        } catch (_: Exception) {
            // Fall back to content URI if stream read fails
        }

        val localUriString = if (localFile.exists() && localFile.length() > 0) {
            Uri.fromFile(localFile).toString()
        } else {
            uri.toString()
        }

        val payloadUrl = copiedBytes?.let { bytes ->
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            "data:$mimeType;base64,$b64"
        } ?: uri.toString()

        PreparedFileAttachment(
            uriString = localUriString,
            fileUrlForPayload = payloadUrl,
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = fileSize.coerceAtLeast(0L),
        )
    }

    suspend fun encodeAudioFileAsDataUrl(file: File): String = withContext(Dispatchers.IO) {
        if (!file.exists() || file.length() == 0L) return@withContext Uri.fromFile(file).toString()
        val maxBytes = 3L * 1024L * 1024L
        if (file.length() <= maxBytes) {
            val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            "data:audio/mp4;base64,$b64"
        } else {
            Uri.fromFile(file).toString()
        }
    }
}
