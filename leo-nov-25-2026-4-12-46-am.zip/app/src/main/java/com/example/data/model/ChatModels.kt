package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class RoutingOption(val label: String) {
    ANIME("Anime"),
    PHILOSOPHY("Philosophy"),
    CONTENT("Content"),
    GENERAL("General");

    companion object {
        fun fromLabel(label: String): RoutingOption {
            return entries.firstOrNull { it.label.equals(label, ignoreCase = true) } ?: GENERAL
        }
    }
}

enum class MessageSender {
    USER,
    LEO,
    SYSTEM,
}

enum class MessageType(val wireValue: String) {
    VOICE("voice"),
    TEXT("text"),
    FILE("file");

    companion object {
        fun fromWireValue(value: String): MessageType {
            return entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: TEXT
        }
    }
}

@JsonClass(generateAdapter = true)
data class WebhookRequestPayload(
    @Json(name = "message_type") val messageType: String,
    @Json(name = "content") val content: String,
    @Json(name = "dropdown_selection") val dropdownSelection: String,
    @Json(name = "file_url") val fileUrl: String? = null,
)

data class PreparedFileAttachment(
    val uriString: String,
    val fileUrlForPayload: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
)
