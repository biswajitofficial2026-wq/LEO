package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class TtsManager(context: Context) {

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speakingMessageId = MutableStateFlow<Long?>(null)
    val speakingMessageId: StateFlow<Long?> = _speakingMessageId.asStateFlow()

    private var tts: TextToSpeech? = null
    private var pendingUtterance: Triple<String, Long?, Float>? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                engine?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val langResult = engine?.setLanguage(Locale.getDefault())
                if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                    langResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    engine.setLanguage(Locale.US)
                }
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _speakingMessageId.value = null
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _speakingMessageId.value = null
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _speakingMessageId.value = null
                    }
                })
                _isReady.value = true
                pendingUtterance?.let { (text, msgId, rate) ->
                    pendingUtterance = null
                    speak(text = text, messageId = msgId, speechRate = rate)
                }
            } else {
                _isReady.value = false
            }
        }
    }

    fun speak(
        text: String,
        messageId: Long? = null,
        speechRate: Float = 1.05f,
    ) {
        val cleaned = sanitizeForSpeech(text)
        if (cleaned.isBlank()) return

        if (!_isReady.value) {
            pendingUtterance = Triple(cleaned, messageId, speechRate)
            return
        }

        val engine = tts ?: return
        engine.setSpeechRate(speechRate.coerceIn(0.75f, 1.5f))
        _speakingMessageId.value = messageId
        _isSpeaking.value = true
        val utteranceId = messageId?.toString() ?: UUID.randomUUID().toString()
        engine.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        pendingUtterance = null
        tts?.stop()
        _isSpeaking.value = false
        _speakingMessageId.value = null
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        _isReady.value = false
    }

    private fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("```[\\s\\S]*?```"), " code block omitted ")
            .replace(Regex("[*_`#>~]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
