package com.example.audio

import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

sealed interface VoiceCaptureResult {
    data class Transcript(val text: String) : VoiceCaptureResult
    data class AudioClip(val file: File, val durationMs: Long) : VoiceCaptureResult
    data class Error(val message: String) : VoiceCaptureResult
    data object Cancelled : VoiceCaptureResult
}

class VoiceInputManager(private val context: Context) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _voiceRms = MutableStateFlow(0f)
    val voiceRms: StateFlow<Float> = _voiceRms.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var currentAudioFile: File? = null
    private var recordingStartMs: Long = 0L
    private var isUsingSpeechRecognizer: Boolean = false
    private var isActiveSession: Boolean = false
    private var pendingCallback: ((VoiceCaptureResult) -> Unit)? = null
    private var rmsPollingRunnable: Runnable? = null

    fun startListening(onResult: (VoiceCaptureResult) -> Unit) {
        mainHandler.post {
            cleanupSession()
            isActiveSession = true
            pendingCallback = onResult
            _partialTranscript.value = ""
            _voiceRms.value = 0f
            recordingStartMs = System.currentTimeMillis()

            if (SpeechRecognizer.isRecognitionAvailable(appContext)) {
                startSpeechRecognizerSession()
            } else {
                startMediaRecorderSession()
            }
        }
    }

    fun stopAndDeliver() {
        mainHandler.post {
            if (!isActiveSession) return@post
            val elapsedMs = System.currentTimeMillis() - recordingStartMs

            if (elapsedMs < 300L) {
                cancel()
                pendingCallback?.invoke(VoiceCaptureResult.Error("Hold the button while speaking"))
                pendingCallback = null
                return@post
            }

            if (isUsingSpeechRecognizer) {
                val recognizer = speechRecognizer
                if (recognizer != null) {
                    // Schedule a safety timeout in case onResults never fires
                    mainHandler.postDelayed({
                        if (isActiveSession) {
                            val partial = _partialTranscript.value.trim()
                            val cb = pendingCallback
                            cleanupSession()
                            if (partial.isNotEmpty()) {
                                cb?.invoke(VoiceCaptureResult.Transcript(partial))
                            } else {
                                cb?.invoke(VoiceCaptureResult.Error("Didn't catch any speech. Try again."))
                            }
                        }
                    }, 2200L)
                    recognizer.stopListening()
                } else {
                    val cb = pendingCallback
                    cleanupSession()
                    cb?.invoke(VoiceCaptureResult.Error("Speech engine unavailable"))
                }
            } else {
                deliverMediaRecorderClip()
            }
        }
    }

    fun cancel() {
        mainHandler.post {
            val cb = pendingCallback
            cleanupSession()
            cb?.invoke(VoiceCaptureResult.Cancelled)
        }
    }

    fun destroy() {
        mainHandler.post {
            cleanupSession()
        }
    }

    private fun startSpeechRecognizerSession() {
        isUsingSpeechRecognizer = true
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
            speechRecognizer = recognizer

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    // Normalize Android SpeechRecognizer RMS (-2..10 dB) into 0f..1f
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _voiceRms.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    if (!isActiveSession) return
                    val partial = _partialTranscript.value.trim()
                    val cb = pendingCallback

                    // If SpeechRecognizer failed with client/server/recognizer-busy error and we haven't captured text,
                    // give a helpful driver-friendly message.
                    if (partial.isNotEmpty()) {
                        cleanupSession()
                        cb?.invoke(VoiceCaptureResult.Transcript(partial))
                        return
                    }

                    val message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Hold and speak clearly."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition offline; check connection."
                        else -> "Voice capture failed (code $error). Try again."
                    }
                    cleanupSession()
                    cb?.invoke(VoiceCaptureResult.Error(message))
                }

                override fun onResults(results: Bundle?) {
                    if (!isActiveSession) return
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val transcript = matches?.firstOrNull()?.trim().orEmpty()
                        .ifEmpty { _partialTranscript.value.trim() }
                    val cb = pendingCallback
                    cleanupSession()
                    if (transcript.isNotEmpty()) {
                        cb?.invoke(VoiceCaptureResult.Transcript(transcript))
                    } else {
                        cb?.invoke(VoiceCaptureResult.Error("No speech detected. Hold and speak clearly."))
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull()?.trim().orEmpty()
                    if (partial.isNotEmpty()) {
                        _partialTranscript.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            // Fallback seamlessly to MediaRecorder audio capture
            speechRecognizer?.destroy()
            speechRecognizer = null
            startMediaRecorderSession()
        }
    }

    private fun startMediaRecorderSession() {
        isUsingSpeechRecognizer = false
        val audioDir = File(appContext.cacheDir, "voice_notes").apply { mkdirs() }
        val outputFile = File(audioDir, "leo_voice_${System.currentTimeMillis()}.m4a")
        currentAudioFile = outputFile

        try {
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(appContext)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            startRmsPolling(recorder)
        } catch (e: Exception) {
            val cb = pendingCallback
            cleanupSession()
            cb?.invoke(
                VoiceCaptureResult.Error("Unable to access microphone: ${e.localizedMessage ?: "unknown error"}")
            )
        }
    }

    private fun startRmsPolling(recorder: MediaRecorder) {
        val runnable = object : Runnable {
            override fun run() {
                if (!isActiveSession) return
                val amplitude = try {
                    recorder.maxAmplitude
                } catch (_: Exception) {
                    0
                }
                _voiceRms.value = (amplitude / 20000f).coerceIn(0f, 1f)
                mainHandler.postDelayed(this, 80L)
            }
        }
        rmsPollingRunnable = runnable
        mainHandler.post(runnable)
    }

    private fun deliverMediaRecorderClip() {
        val durationMs = (System.currentTimeMillis() - recordingStartMs).coerceAtLeast(0L)
        val file = currentAudioFile
        val cb = pendingCallback
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
            // Ignore stop error on very brief audio
        }
        mediaRecorder = null
        rmsPollingRunnable?.let { mainHandler.removeCallbacks(it) }
        rmsPollingRunnable = null
        isActiveSession = false
        pendingCallback = null
        _voiceRms.value = 0f

        if (file != null && file.exists() && file.length() > 0L) {
            cb?.invoke(VoiceCaptureResult.AudioClip(file = file, durationMs = durationMs))
        } else {
            cb?.invoke(VoiceCaptureResult.Error("Voice recording was empty."))
        }
    }

    private fun cleanupSession() {
        mainHandler.removeCallbacksAndMessages(null)
        rmsPollingRunnable = null
        isActiveSession = false
        pendingCallback = null
        _voiceRms.value = 0f

        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null

        try {
            mediaRecorder?.reset()
            mediaRecorder?.release()
        } catch (_: Exception) {
        }
        mediaRecorder = null
    }
}
