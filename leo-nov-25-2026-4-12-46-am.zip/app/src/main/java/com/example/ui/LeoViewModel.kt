package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TtsManager
import com.example.audio.VoiceCaptureResult
import com.example.audio.VoiceInputManager
import com.example.data.local.LeoDatabase
import com.example.data.local.SettingsDataStore
import com.example.data.model.MessageSender
import com.example.data.model.MessageType
import com.example.data.model.RoutingOption
import com.example.data.repository.LeoRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class LeoViewModel(application: Application) : AndroidViewModel(application) {

    private val database = LeoDatabase.getInstance(application)
    private val settingsDataStore = SettingsDataStore(application)
    private val repository = LeoRepository(
        context = application,
        chatMessageDao = database.chatMessageDao(),
        settingsDataStore = settingsDataStore,
    )

    private val ttsManager = TtsManager(application)
    private val voiceInputManager = VoiceInputManager(application)

    private val _uiState = MutableStateFlow(LeoUiState())
    val uiState: StateFlow<LeoUiState> = _uiState.asStateFlow()

    private var recordingTimerJob: Job? = null

    init {
        viewModelScope.launch {
            combine(
                repository.messages,
                repository.webhookUrl,
                repository.selectedRouting,
                repository.autoSpeakEnabled,
                repository.speechRate,
            ) { messages, webhookUrl, routing, autoSpeak, rate ->
                PersistedSlice(messages, webhookUrl, routing, autoSpeak, rate)
            }.collect { slice ->
                _uiState.update { current ->
                    current.copy(
                        messages = slice.messages,
                        webhookUrl = slice.webhookUrl,
                        selectedRouting = slice.routing,
                        autoSpeakEnabled = slice.autoSpeak,
                        speechRate = slice.speechRate,
                    )
                }
            }
        }

        viewModelScope.launch {
            ttsManager.isReady.collect { ready ->
                _uiState.update { it.copy(isTtsReady = ready) }
            }
        }

        viewModelScope.launch {
            ttsManager.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }

        viewModelScope.launch {
            ttsManager.speakingMessageId.collect { msgId ->
                _uiState.update { it.copy(speakingMessageId = msgId) }
            }
        }

        viewModelScope.launch {
            voiceInputManager.partialTranscript.collect { partial ->
                _uiState.update { it.copy(partialTranscript = partial) }
            }
        }

        viewModelScope.launch {
            voiceInputManager.voiceRms.collect { rms ->
                _uiState.update { it.copy(voiceRms = rms) }
            }
        }
    }

    fun onDraftTextChanged(text: String) {
        _uiState.update { it.copy(draftText = text) }
    }

    fun onRoutingSelected(option: RoutingOption) {
        viewModelScope.launch {
            repository.saveSelectedRouting(option)
        }
    }

    fun openSettings() {
        _uiState.update { it.copy(isSettingsOpen = true, webhookTestResult = null) }
    }

    fun closeSettings() {
        _uiState.update { it.copy(isSettingsOpen = false, webhookTestResult = null) }
    }

    fun saveSettings(webhookUrl: String, autoSpeak: Boolean, speechRate: Float) {
        viewModelScope.launch {
            repository.saveWebhookUrl(webhookUrl)
            repository.saveAutoSpeakEnabled(autoSpeak)
            repository.saveSpeechRate(speechRate)
            if (!autoSpeak) {
                ttsManager.stop()
            }
            _uiState.update {
                it.copy(
                    isSettingsOpen = false,
                    webhookTestResult = null,
                    statusNotice = "Settings saved",
                )
            }
        }
    }

    fun toggleAutoSpeak() {
        val next = !_uiState.value.autoSpeakEnabled
        viewModelScope.launch {
            repository.saveAutoSpeakEnabled(next)
            if (!next) {
                ttsManager.stop()
            } else {
                _uiState.update { it.copy(statusNotice = "Voice readback enabled") }
            }
        }
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    fun replayMessageSpeech(messageId: Long, content: String) {
        if (_uiState.value.speakingMessageId == messageId && _uiState.value.isSpeaking) {
            ttsManager.stop()
        } else {
            ttsManager.speak(
                text = content,
                messageId = messageId,
                speechRate = _uiState.value.speechRate,
            )
        }
    }

    fun clearStatusNotice() {
        _uiState.update { it.copy(statusNotice = null) }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            ttsManager.stop()
            repository.clearChatHistory()
            _uiState.update { it.copy(statusNotice = "Chat history cleared") }
        }
    }

    fun testWebhookConnection(candidateUrl: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingWebhook = true, webhookTestResult = null) }
            val result = repository.dispatchToWebhook(
                webhookUrl = candidateUrl,
                messageType = MessageType.TEXT,
                content = "Ping from LEO cockpit",
                routingOption = _uiState.value.selectedRouting,
                fileUrl = null,
            )
            result.onSuccess { reply ->
                _uiState.update {
                    it.copy(
                        isTestingWebhook = false,
                        webhookTestResult = "Connected! Reply: ${reply.take(120)}",
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isTestingWebhook = false,
                        webhookTestResult = "Failed: ${err.localizedMessage ?: "Unknown error"}",
                    )
                }
            }
        }
    }

    fun submitTextMessage() {
        val text = _uiState.value.draftText.trim()
        if (text.isEmpty() || _uiState.value.isSending) return
        _uiState.update { it.copy(draftText = "") }
        dispatchMessage(
            messageType = MessageType.TEXT,
            content = text,
            fileUrl = null,
            fileName = null,
            fileMimeType = null,
        )
    }

    fun onFilePicked(uri: Uri) {
        if (_uiState.value.isSending) return
        viewModelScope.launch {
            val draft = _uiState.value.draftText.trim()
            if (draft.isNotEmpty()) {
                _uiState.update { it.copy(draftText = "") }
            }
            val attachment = repository.prepareFileAttachment(uri)
            val contentText = draft.ifEmpty { "Shared file: ${attachment.fileName}" }
            dispatchMessage(
                messageType = MessageType.FILE,
                content = contentText,
                fileUrl = attachment.fileUrlForPayload,
                localDisplayFileUrl = attachment.uriString,
                fileName = attachment.fileName,
                fileMimeType = attachment.mimeType,
            )
        }
    }

    fun startVoiceHold() {
        if (_uiState.value.isRecording || _uiState.value.isSending) return
        ttsManager.stop()
        _uiState.update {
            it.copy(
                isRecording = true,
                isProcessingVoice = false,
                recordingDurationMs = 0L,
                partialTranscript = "",
                voiceRms = 0f,
            )
        }

        recordingTimerJob?.cancel()
        recordingTimerJob = viewModelScope.launch {
            val start = System.currentTimeMillis()
            while (_uiState.value.isRecording) {
                _uiState.update { it.copy(recordingDurationMs = System.currentTimeMillis() - start) }
                delay(100L)
            }
        }

        voiceInputManager.startListening { result ->
            recordingTimerJob?.cancel()
            _uiState.update {
                it.copy(
                    isRecording = false,
                    isProcessingVoice = false,
                    recordingDurationMs = 0L,
                    partialTranscript = "",
                    voiceRms = 0f,
                )
            }

            when (result) {
                is VoiceCaptureResult.Transcript -> {
                    dispatchMessage(
                        messageType = MessageType.VOICE,
                        content = result.text,
                        fileUrl = null,
                        fileName = null,
                        fileMimeType = null,
                    )
                }

                is VoiceCaptureResult.AudioClip -> {
                    viewModelScope.launch {
                        val seconds = (result.durationMs / 1000.0).coerceAtLeast(0.5)
                        val formattedSec = String.format(java.util.Locale.US, "%.1fs", seconds)
                        val audioDataUrl = repository.encodeAudioFileAsDataUrl(result.file)
                        dispatchMessage(
                            messageType = MessageType.VOICE,
                            content = "Voice note ($formattedSec)",
                            fileUrl = audioDataUrl,
                            localDisplayFileUrl = result.file.toURI().toString(),
                            fileName = result.file.name,
                            fileMimeType = "audio/mp4",
                        )
                    }
                }

                is VoiceCaptureResult.Error -> {
                    _uiState.update { it.copy(statusNotice = result.message) }
                    if (_uiState.value.autoSpeakEnabled) {
                        ttsManager.speak(
                            text = result.message,
                            messageId = null,
                            speechRate = _uiState.value.speechRate,
                        )
                    }
                }

                VoiceCaptureResult.Cancelled -> Unit
            }
        }
    }

    fun releaseVoiceHold() {
        if (!_uiState.value.isRecording) return
        recordingTimerJob?.cancel()
        _uiState.update { it.copy(isRecording = false, isProcessingVoice = true) }
        voiceInputManager.stopAndDeliver()
    }

    fun cancelVoiceHold() {
        if (!_uiState.value.isRecording && !_uiState.value.isProcessingVoice) return
        recordingTimerJob?.cancel()
        _uiState.update {
            it.copy(
                isRecording = false,
                isProcessingVoice = false,
                recordingDurationMs = 0L,
                partialTranscript = "",
                voiceRms = 0f,
            )
        }
        voiceInputManager.cancel()
    }

    private fun dispatchMessage(
        messageType: MessageType,
        content: String,
        fileUrl: String?,
        localDisplayFileUrl: String? = fileUrl,
        fileName: String?,
        fileMimeType: String?,
    ) {
        val state = _uiState.value
        val routing = state.selectedRouting
        val webhookUrl = state.webhookUrl.trim()

        viewModelScope.launch {
            repository.insertMessage(
                sender = MessageSender.USER,
                messageType = messageType,
                content = content,
                routingOption = routing,
                fileUrl = localDisplayFileUrl,
                fileName = fileName,
                fileMimeType = fileMimeType,
            )

            if (webhookUrl.isBlank()) {
                val warning = "Webhook URL is not configured yet. Tap Settings to enter your custom webhook URL."
                val msgId = repository.insertMessage(
                    sender = MessageSender.LEO,
                    messageType = MessageType.TEXT,
                    content = warning,
                    routingOption = routing,
                    isError = true,
                )
                if (_uiState.value.autoSpeakEnabled) {
                    ttsManager.speak(warning, msgId, _uiState.value.speechRate)
                }
                _uiState.update { it.copy(isSettingsOpen = true) }
                return@launch
            }

            _uiState.update { it.copy(isSending = true) }
            val result = repository.dispatchToWebhook(
                webhookUrl = webhookUrl,
                messageType = messageType,
                content = content,
                routingOption = routing,
                fileUrl = fileUrl,
            )
            _uiState.update { it.copy(isSending = false) }

            result.onSuccess { responseText ->
                val leoMsgId = repository.insertMessage(
                    sender = MessageSender.LEO,
                    messageType = MessageType.TEXT,
                    content = responseText,
                    routingOption = routing,
                    isError = false,
                )
                if (_uiState.value.autoSpeakEnabled) {
                    ttsManager.speak(
                        text = responseText,
                        messageId = leoMsgId,
                        speechRate = _uiState.value.speechRate,
                    )
                }
            }.onFailure { err ->
                val errorText = err.localizedMessage ?: "Failed to reach LEO webhook."
                val errorMsgId = repository.insertMessage(
                    sender = MessageSender.LEO,
                    messageType = MessageType.TEXT,
                    content = errorText,
                    routingOption = routing,
                    isError = true,
                )
                if (_uiState.value.autoSpeakEnabled) {
                    ttsManager.speak(
                        text = "Error: $errorText",
                        messageId = errorMsgId,
                        speechRate = _uiState.value.speechRate,
                    )
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        recordingTimerJob?.cancel()
        voiceInputManager.destroy()
        ttsManager.shutdown()
    }

    private data class PersistedSlice(
        val messages: List<com.example.data.local.ChatMessageEntity>,
        val webhookUrl: String,
        val routing: RoutingOption,
        val autoSpeak: Boolean,
        val speechRate: Float,
    )
}
