package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ChatHistorySection
import com.example.ui.components.HoldToSpeakButton
import com.example.ui.components.InputToolbar
import com.example.ui.components.TopHudBar
import com.example.ui.components.WebhookSettingsSheet
import com.example.ui.theme.CockpitObsidian
import com.example.ui.theme.CockpitOutlineBright
import com.example.ui.theme.CockpitSurfaceHighest
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LeoCockpitScreen(
    viewModel: LeoViewModel,
    modifier: Modifier = Modifier,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val imeVisible = WindowInsets.isImeVisible

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        coroutineScope.launch {
            if (granted) {
                snackbarHostState.showSnackbar("Microphone ready — hold the button to speak")
            } else {
                snackbarHostState.showSnackbar("Microphone permission is required for voice input")
            }
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        uri?.let { viewModel.onFilePicked(it) }
    }

    LaunchedEffect(uiState.statusNotice) {
        val notice = uiState.statusNotice ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(notice)
        viewModel.clearStatusNotice()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CockpitObsidian,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = CockpitSurfaceHighest,
                    contentColor = TextPrimary,
                    actionColor = LeoAmber,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding(),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize(),
            ) {
                if (imeVisible) {
                    // Keyboard-active layout: keep chat visible and toolbar anchored above keyboard
                    TopHudBar(
                        webhookUrl = uiState.webhookUrl,
                        isSpeaking = uiState.isSpeaking,
                        autoSpeakEnabled = uiState.autoSpeakEnabled,
                        isSending = uiState.isSending,
                        onToggleAutoSpeak = viewModel::toggleAutoSpeak,
                        onStopSpeaking = viewModel::stopSpeaking,
                        onOpenSettings = viewModel::openSettings,
                    )
                    ChatHistorySection(
                        messages = uiState.messages,
                        isSending = uiState.isSending,
                        speakingMessageId = uiState.speakingMessageId,
                        isSpeaking = uiState.isSpeaking,
                        webhookUrl = uiState.webhookUrl,
                        onReplaySpeech = viewModel::replayMessageSpeech,
                        onOpenSettings = viewModel::openSettings,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    )
                    InputToolbar(
                        draftText = uiState.draftText,
                        selectedRouting = uiState.selectedRouting,
                        isSending = uiState.isSending,
                        onDraftTextChanged = viewModel::onDraftTextChanged,
                        onSendText = {
                            focusManager.clearFocus()
                            viewModel.submitTextMessage()
                        },
                        onAttachFile = {
                            filePickerLauncher.launch(
                                arrayOf(
                                    "image/*",
                                    "video/*",
                                    "application/pdf",
                                    "text/*",
                                    "application/*",
                                )
                            )
                        },
                        onRoutingSelected = viewModel::onRoutingSelected,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                } else {
                    // Eyes-Free Driver Cockpit Layout: Top 60% Chat History / Bottom 40% Toolbar + Massive Hold-to-Speak
                    Column(
                        modifier = Modifier
                            .weight(0.60f)
                            .fillMaxWidth(),
                    ) {
                        TopHudBar(
                            webhookUrl = uiState.webhookUrl,
                            isSpeaking = uiState.isSpeaking,
                            autoSpeakEnabled = uiState.autoSpeakEnabled,
                            isSending = uiState.isSending,
                            onToggleAutoSpeak = viewModel::toggleAutoSpeak,
                            onStopSpeaking = viewModel::stopSpeaking,
                            onOpenSettings = viewModel::openSettings,
                        )
                        ChatHistorySection(
                            messages = uiState.messages,
                            isSending = uiState.isSending,
                            speakingMessageId = uiState.speakingMessageId,
                            isSpeaking = uiState.isSpeaking,
                            webhookUrl = uiState.webhookUrl,
                            onReplaySpeech = viewModel::replayMessageSpeech,
                            onOpenSettings = viewModel::openSettings,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.40f)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        InputToolbar(
                            draftText = uiState.draftText,
                            selectedRouting = uiState.selectedRouting,
                            isSending = uiState.isSending,
                            onDraftTextChanged = viewModel::onDraftTextChanged,
                            onSendText = {
                                focusManager.clearFocus()
                                viewModel.submitTextMessage()
                            },
                            onAttachFile = {
                                filePickerLauncher.launch(
                                    arrayOf(
                                        "image/*",
                                        "video/*",
                                        "application/pdf",
                                        "text/*",
                                        "application/*",
                                    )
                                )
                            },
                            onRoutingSelected = viewModel::onRoutingSelected,
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        HoldToSpeakButton(
                            isRecording = uiState.isRecording,
                            isProcessingVoice = uiState.isProcessingVoice,
                            isSending = uiState.isSending,
                            recordingDurationMs = uiState.recordingDurationMs,
                            partialTranscript = uiState.partialTranscript,
                            voiceRms = uiState.voiceRms,
                            selectedRouting = uiState.selectedRouting,
                            onHoldStart = {
                                focusManager.clearFocus()
                                val hasMic = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO,
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasMic) {
                                    viewModel.startVoiceHold()
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            onHoldRelease = viewModel::releaseVoiceHold,
                            onHoldCancel = viewModel::cancelVoiceHold,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                        )
                    }
                }
            }
        }
    }

    if (uiState.isSettingsOpen) {
        WebhookSettingsSheet(
            currentWebhookUrl = uiState.webhookUrl,
            currentAutoSpeak = uiState.autoSpeakEnabled,
            currentSpeechRate = uiState.speechRate,
            isTestingWebhook = uiState.isTestingWebhook,
            webhookTestResult = uiState.webhookTestResult,
            onTestWebhook = viewModel::testWebhookConnection,
            onSaveSettings = viewModel::saveSettings,
            onClearChatHistory = viewModel::clearChatHistory,
            onDismiss = viewModel::closeSettings,
        )
    }
}
