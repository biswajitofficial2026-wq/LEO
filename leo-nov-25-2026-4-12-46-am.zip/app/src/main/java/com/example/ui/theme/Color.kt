package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Night Cockpit Palette — High-contrast automotive dark theme for LEO
val CockpitObsidian = Color(0xFF070B11)
val CockpitSurface = Color(0xFF0E1520)
val CockpitSurfaceElevated = Color(0xFF151F2E)
val CockpitSurfaceHighest = Color(0xFF1E2B3E)
val CockpitOutline = Color(0xFF2B3B52)
val CockpitOutlineBright = Color(0xFF3E5372)

// Primary Brand Accent — High-visibility Amber Gold for driver controls
val LeoAmber = Color(0xFFFFB300)
val LeoAmberPressed = Color(0xFFFF8F00)
val LeoAmberContainer = Color(0xFF332300)
val OnLeoAmber = Color(0xFF1A1100)

// Secondary Telemetry Accent — Electric Cyan for LEO AI & TTS voice active state
val LeoCyan = Color(0xFF22D3EE)
val LeoCyanContainer = Color(0xFF0B2E38)
val OnLeoCyan = Color(0xFF031B22)

// Tertiary & Status Accents
val RecordingCrimson = Color(0xFFEF4444)
val RecordingCrimsonContainer = Color(0xFF3B0D11)
val ReadyEmerald = Color(0xFF10B981)
val ReadyEmeraldContainer = Color(0xFF082D21)

// Routing Category Accents
val RouteAnimeViolet = Color(0xFFC084FC)
val RoutePhilosophyGold = Color(0xFFFBBF24)
val RouteContentCyan = Color(0xFF38BDF8)
val RouteGeneralSlate = Color(0xFF94A3B8)

// Text Hierarchy
val TextPrimary = Color(0xFFF4F7FB)
val TextSecondary = Color(0xFF9BAAC0)
val TextMuted = Color(0xFF667892)
