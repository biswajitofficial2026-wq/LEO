package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.RoutingOption
import com.example.ui.theme.CockpitOutlineBright
import com.example.ui.theme.CockpitSurfaceElevated
import com.example.ui.theme.CockpitSurfaceHighest
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.LeoAmberContainer
import com.example.ui.theme.LeoCyan
import com.example.ui.theme.OnLeoAmber
import com.example.ui.theme.RecordingCrimson
import com.example.ui.theme.RecordingCrimsonContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun HoldToSpeakButton(
    isRecording: Boolean,
    isProcessingVoice: Boolean,
    isSending: Boolean,
    recordingDurationMs: Long,
    partialTranscript: String,
    voiceRms: Float,
    selectedRouting: RoutingOption,
    onHoldStart: () -> Unit,
    onHoldRelease: () -> Unit,
    onHoldCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    val currentOnHoldStart by rememberUpdatedState(onHoldStart)
    val currentOnHoldRelease by rememberUpdatedState(onHoldRelease)
    val currentOnHoldCancel by rememberUpdatedState(onHoldCancel)
    val currentIsSending by rememberUpdatedState(isSending)

    val buttonScale by animateFloatAsState(
        targetValue = if (isRecording) 0.975f else 1f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 500f),
        label = "mic_scale",
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isRecording -> RecordingCrimson
            isProcessingVoice || isSending -> LeoCyan
            else -> LeoAmber
        },
        label = "mic_border_color",
    )

    val containerBrush = when {
        isRecording -> Brush.radialGradient(
            colors = listOf(
                RecordingCrimson.copy(alpha = 0.34f),
                RecordingCrimsonContainer,
            )
        )
        isProcessingVoice || isSending -> Brush.radialGradient(
            colors = listOf(
                LeoCyan.copy(alpha = 0.2f),
                CockpitSurfaceElevated,
            )
        )
        else -> Brush.radialGradient(
            colors = listOf(
                LeoAmberContainer.copy(alpha = 0.95f),
                CockpitSurfaceHighest,
            )
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "mic_rings")
    val ringProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "ring_progress",
    )

    val formattedDuration = rememberDurationText(recordingDurationMs)

    Surface(
        modifier = modifier
            .fillMaxSize()
            .scale(buttonScale)
            .semantics {
                role = Role.Button
                contentDescription = if (isRecording) {
                    "Listening. Release to send voice message to LEO."
                } else {
                    "Hold to speak to LEO. Routing mode ${selectedRouting.label}."
                }
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    if (currentIsSending) return@awaitEachGesture

                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    currentOnHoldStart()

                    var cancelled = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val anyPressed = event.changes.any { it.pressed }
                        if (!anyPressed) {
                            break
                        }
                        // Only cancel if system consumes pointer cancel (not slight thumb drift!)
                        if (event.changes.all { it.isConsumed && !it.pressed }) {
                            cancelled = true
                            break
                        }
                    }

                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    if (cancelled) {
                        currentOnHoldCancel()
                    } else {
                        currentOnHoldRelease()
                    }
                }
            }
            .testTag("hold_to_speak_button"),
        shape = RoundedCornerShape(28.dp),
        color = Color.Transparent,
        border = BorderStroke(
            width = if (isRecording) 2.5.dp else 1.5.dp,
            color = borderColor.copy(alpha = if (isRecording) 1f else 0.75f),
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(containerBrush)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            // Acoustic sonar rings behind the mic core when recording or idle
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = (minOf(size.width, size.height) / 2f) * 0.94f
                if (isRecording) {
                    val rmsBoost = 1f + (voiceRms * 0.25f)
                    val radius1 = (maxRadius * 0.42f) + (maxRadius * 0.52f * ringProgress * rmsBoost)
                    val radius2 = (maxRadius * 0.42f) + (maxRadius * 0.52f * ((ringProgress + 0.5f) % 1f) * rmsBoost)
                    drawCircle(
                        color = RecordingCrimson.copy(alpha = (1f - ringProgress) * 0.55f),
                        radius = radius1.coerceAtMost(maxRadius),
                        center = center,
                        style = Stroke(width = 4.dp.toPx()),
                    )
                    drawCircle(
                        color = RecordingCrimson.copy(alpha = (1f - ((ringProgress + 0.5f) % 1f)) * 0.45f),
                        radius = radius2.coerceAtMost(maxRadius),
                        center = center,
                        style = Stroke(width = 3.dp.toPx()),
                    )
                } else {
                    drawCircle(
                        color = CockpitOutlineBright.copy(alpha = 0.25f),
                        radius = maxRadius * 0.78f,
                        center = center,
                        style = Stroke(width = 1.dp.toPx()),
                    )
                    drawCircle(
                        color = LeoAmber.copy(alpha = 0.16f),
                        radius = maxRadius * 0.56f,
                        center = center,
                        style = Stroke(width = 1.dp.toPx()),
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth(),
            ) {
                // Center glowing mic medallion
                Box(
                    modifier = Modifier
                        .size(if (isRecording) 82.dp else 76.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isRecording -> RecordingCrimson
                                isProcessingVoice || isSending -> LeoCyan.copy(alpha = 0.2f)
                                else -> LeoAmber
                            }
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    when {
                        isProcessingVoice || isSending -> {
                            CircularProgressIndicator(
                                modifier = Modifier.size(34.dp),
                                color = LeoCyan,
                                strokeWidth = 3.dp,
                            )
                        }
                        isRecording -> {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = TextPrimary,
                                modifier = Modifier.size(42.dp),
                            )
                        }
                        else -> {
                            Icon(
                                imageVector = Icons.Rounded.Mic,
                                contentDescription = null,
                                tint = OnLeoAmber,
                                modifier = Modifier.size(40.dp),
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Primary driver-facing label
                Text(
                    text = when {
                        isRecording -> stringResource(R.string.listening_release)
                        isProcessingVoice -> stringResource(R.string.processing_voice)
                        isSending -> stringResource(R.string.sending_to_leo)
                        else -> stringResource(R.string.hold_to_speak)
                    },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        isRecording -> RecordingCrimson
                        isProcessingVoice || isSending -> LeoCyan
                        else -> TextPrimary
                    },
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Sub-status: live partial transcript / timer / active routing mode
                if (isRecording) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            text = formattedDuration,
                            style = MaterialTheme.typography.labelMedium,
                            color = RecordingCrimson,
                            fontWeight = FontWeight.Bold,
                        )
                        if (partialTranscript.isNotBlank()) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "“$partialTranscript”",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                } else {
                    Text(
                        text = "Mode: ${selectedRouting.label} • Eyes-free voice dispatch",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun rememberDurationText(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000L).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
