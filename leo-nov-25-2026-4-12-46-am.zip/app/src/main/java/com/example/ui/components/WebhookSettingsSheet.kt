package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CockpitOutline
import com.example.ui.theme.CockpitOutlineBright
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceElevated
import com.example.ui.theme.CockpitSurfaceHighest
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.LeoCyan
import com.example.ui.theme.OnLeoAmber
import com.example.ui.theme.ReadyEmerald
import com.example.ui.theme.RecordingCrimson
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebhookSettingsSheet(
    currentWebhookUrl: String,
    currentAutoSpeak: Boolean,
    currentSpeechRate: Float,
    isTestingWebhook: Boolean,
    webhookTestResult: String?,
    onTestWebhook: (String) -> Unit,
    onSaveSettings: (webhookUrl: String, autoSpeak: Boolean, speechRate: Float) -> Unit,
    onClearChatHistory: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var urlDraft by remember(currentWebhookUrl) { mutableStateOf(currentWebhookUrl) }
    var autoSpeakDraft by remember(currentAutoSpeak) { mutableStateOf(currentAutoSpeak) }
    var speechRateDraft by remember(currentSpeechRate) { mutableFloatStateOf(currentSpeechRate) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CockpitSurface,
        contentColor = TextPrimary,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "LEO COCKPIT SETTINGS",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
            )

            // Webhook URL Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Custom Webhook URL",
                    style = MaterialTheme.typography.titleSmall,
                    color = LeoAmber,
                )
                Text(
                    text = "Voice, text, and file submissions POST JSON with message_type, content, dropdown_selection, and file_url.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
                OutlinedTextField(
                    value = urlDraft,
                    onValueChange = { urlDraft = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("webhook_url_input"),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Link,
                            contentDescription = null,
                            tint = LeoAmber,
                        )
                    },
                    placeholder = {
                        Text(
                            text = "https://your-server.com/webhook/leo",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextMuted,
                        )
                    },
                    textStyle = MaterialTheme.typography.labelMedium.copy(color = TextPrimary),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CockpitSurfaceElevated,
                        unfocusedContainerColor = CockpitSurfaceElevated,
                        focusedBorderColor = LeoAmber,
                        unfocusedBorderColor = CockpitOutline,
                        cursorColor = LeoAmber,
                    ),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = { onTestWebhook(urlDraft) },
                        enabled = urlDraft.isNotBlank() && !isTestingWebhook,
                        border = BorderStroke(1.dp, CockpitOutlineBright),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("test_webhook_button"),
                    ) {
                        if (isTestingWebhook) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = LeoCyan,
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = LeoCyan,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Test POST",
                            style = MaterialTheme.typography.labelMedium,
                            color = LeoCyan,
                        )
                    }

                    Button(
                        onClick = { onSaveSettings(urlDraft, autoSpeakDraft, speechRateDraft) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LeoAmber,
                            contentColor = OnLeoAmber,
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("save_settings_button"),
                    ) {
                        Text(
                            text = "Save",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }

                if (!webhookTestResult.isNullOrBlank()) {
                    val isSuccess = webhookTestResult.startsWith("Connected")
                    Surface(
                        color = CockpitSurfaceHighest,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isSuccess) ReadyEmerald else RecordingCrimson,
                        ),
                    ) {
                        Text(
                            text = webhookTestResult,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSuccess) ReadyEmerald else RecordingCrimson,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .testTag("webhook_test_result"),
                        )
                    }
                }
            }

            HorizontalDivider(color = CockpitOutline)

            // TTS Accessibility Controls
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Eyes-Free Voice Readback (TTS)",
                    style = MaterialTheme.typography.titleSmall,
                    color = LeoCyan,
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Auto-Read LEO Responses",
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextPrimary,
                        )
                        Text(
                            text = "Automatically speak incoming webhook replies aloud.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = autoSpeakDraft,
                        onCheckedChange = { autoSpeakDraft = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CockpitSurface,
                            checkedTrackColor = LeoCyan,
                            uncheckedTrackColor = CockpitSurfaceHighest,
                        ),
                        modifier = Modifier.testTag("auto_speak_switch"),
                    )
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "Voice Speed",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                        )
                        Text(
                            text = String.format(Locale.US, "%.2fx", speechRateDraft),
                            style = MaterialTheme.typography.labelMedium,
                            color = LeoCyan,
                        )
                    }
                    Slider(
                        value = speechRateDraft,
                        onValueChange = { speechRateDraft = it },
                        valueRange = 0.75f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = LeoCyan,
                            activeTrackColor = LeoCyan,
                            inactiveTrackColor = CockpitSurfaceHighest,
                        ),
                        modifier = Modifier.testTag("speech_rate_slider"),
                    )
                }
            }

            HorizontalDivider(color = CockpitOutline)

            // Danger / Maintenance Zone
            TextButton(
                onClick = {
                    onClearChatHistory()
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("clear_history_button"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = null,
                    tint = RecordingCrimson,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Clear Chat History",
                    style = MaterialTheme.typography.labelLarge,
                    color = RecordingCrimson,
                )
            }
        }
    }
}
