package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CockpitOutline
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceElevated
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.LeoAmberContainer
import com.example.ui.theme.LeoCyan
import com.example.ui.theme.LeoCyanContainer
import com.example.ui.theme.ReadyEmerald
import com.example.ui.theme.ReadyEmeraldContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TopHudBar(
    webhookUrl: String,
    isSpeaking: Boolean,
    autoSpeakEnabled: Boolean,
    isSending: Boolean,
    onToggleAutoSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val isWebhookSet = webhookUrl.isNotBlank()
    val infiniteTransition = rememberInfiniteTransition(label = "hud_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_alpha",
    )

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = CockpitSurface,
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, CockpitOutline.copy(alpha = 0.6f)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            // Left: LEO Crest + Title + Webhook status pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_leo_foreground_1795559339322),
                    contentDescription = "LEO emblem",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "LEO",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        val statusText = when {
                            isSpeaking -> "SPEAKING"
                            isSending -> "SYNCING"
                            isWebhookSet -> "READY"
                            else -> "SETUP"
                        }
                        val statusColor by animateColorAsState(
                            targetValue = when {
                                isSpeaking -> LeoCyan
                                isSending -> LeoAmber
                                isWebhookSet -> ReadyEmerald
                                else -> LeoAmber
                            },
                            label = "status_color",
                        )
                        val statusBg = when {
                            isSpeaking -> LeoCyanContainer
                            isSending -> LeoAmberContainer
                            isWebhookSet -> ReadyEmeraldContainer
                            else -> LeoAmberContainer
                        }
                        Surface(
                            color = statusBg,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(
                                1.dp,
                                statusColor.copy(alpha = if (isSpeaking || isSending) pulseAlpha else 0.55f),
                            ),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(statusColor),
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    maxLines = 1,
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onOpenSettings)
                            .padding(top = 2.dp),
                    ) {
                        Icon(
                            imageVector = if (isWebhookSet) Icons.Rounded.Link else Icons.Rounded.LinkOff,
                            contentDescription = null,
                            tint = if (isWebhookSet) TextSecondary else LeoAmber,
                            modifier = Modifier.size(13.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isWebhookSet) {
                                webhookUrl.removePrefix("https://").removePrefix("http://")
                            } else {
                                "Tap to set Webhook URL"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isWebhookSet) TextMuted else LeoAmber,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            // Right: TTS Stop/Toggle + Settings
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (isSpeaking) {
                    Surface(
                        onClick = onStopSpeaking,
                        color = LeoCyanContainer,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, LeoCyan),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("stop_speaking_button"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = LeoCyan,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = stringResource(R.string.stop_speech_desc),
                                tint = LeoCyan,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                } else {
                    Surface(
                        onClick = onToggleAutoSpeak,
                        color = if (autoSpeakEnabled) CockpitSurfaceElevated else CockpitSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.dp,
                            if (autoSpeakEnabled) LeoCyan.copy(alpha = 0.5f) else CockpitOutline,
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tts_toggle_button"),
                    ) {
                        Box(
                            modifier = Modifier.padding(11.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = if (autoSpeakEnabled) {
                                    Icons.AutoMirrored.Rounded.VolumeUp
                                } else {
                                    Icons.AutoMirrored.Rounded.VolumeOff
                                },
                                contentDescription = stringResource(R.string.tts_toggle_desc),
                                tint = if (autoSpeakEnabled) LeoCyan else TextMuted,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CockpitSurfaceElevated)
                        .testTag("webhook_settings_button"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = stringResource(R.string.webhook_settings_desc),
                        tint = Color.White,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}
