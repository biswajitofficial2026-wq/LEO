package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.ChatMessageEntity
import com.example.data.model.MessageSender
import com.example.data.model.MessageType
import com.example.data.model.RoutingOption
import com.example.ui.theme.CockpitObsidian
import com.example.ui.theme.CockpitOutline
import com.example.ui.theme.CockpitOutlineBright
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceElevated
import com.example.ui.theme.CockpitSurfaceHighest
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.LeoAmberContainer
import com.example.ui.theme.LeoCyan
import com.example.ui.theme.LeoCyanContainer
import com.example.ui.theme.OnLeoAmber
import com.example.ui.theme.RecordingCrimson
import com.example.ui.theme.RecordingCrimsonContainer
import com.example.ui.theme.RouteAnimeViolet
import com.example.ui.theme.RouteContentCyan
import com.example.ui.theme.RouteGeneralSlate
import com.example.ui.theme.RoutePhilosophyGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatHistorySection(
    messages: List<ChatMessageEntity>,
    isSending: Boolean,
    speakingMessageId: Long?,
    isSpeaking: Boolean,
    webhookUrl: String,
    onReplaySpeech: (Long, String) -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, isSending) {
        val total = messages.size + if (isSending) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CockpitObsidian, CockpitSurface.copy(alpha = 0.7f)),
                )
            ),
    ) {
        if (messages.isEmpty() && !isSending) {
            EmptyCockpitWelcome(
                webhookUrl = webhookUrl,
                onOpenSettings = onOpenSettings,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chat_history_list"),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(
                    items = messages,
                    key = { it.id },
                ) { message ->
                    ChatMessageBubble(
                        message = message,
                        isCurrentlySpeaking = isSpeaking && speakingMessageId == message.id,
                        onReplaySpeech = { onReplaySpeech(message.id, message.content) },
                        onOpenSettings = onOpenSettings,
                        showConfigureAction = message.isError && webhookUrl.isBlank(),
                    )
                }

                if (isSending) {
                    item(key = "sending_indicator") {
                        LeoThinkingIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyCockpitWelcome(
    webhookUrl: String,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_leo_foreground_1795559339322),
            contentDescription = "LEO assistant avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape),
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "EYES-FREE COCKPIT ACTIVE",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Hold the microphone below to speak to LEO. Responses from your webhook are read aloud automatically while you drive.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 360.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        if (webhookUrl.isBlank()) {
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(
                    containerColor = LeoAmber,
                    contentColor = OnLeoAmber,
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("empty_configure_webhook_button"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Set Webhook URL",
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        } else {
            OutlinedButton(
                onClick = onOpenSettings,
                border = BorderStroke(1.dp, CockpitOutlineBright),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("empty_edit_webhook_button"),
            ) {
                Text(
                    text = "Webhook Ready • Tap to Edit",
                    style = MaterialTheme.typography.labelMedium,
                    color = LeoCyan,
                )
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessageEntity,
    isCurrentlySpeaking: Boolean,
    onReplaySpeech: () -> Unit,
    onOpenSettings: () -> Unit,
    showConfigureAction: Boolean,
) {
    val isUser = message.sender == MessageSender.USER.name
    val routing = remember(message.routingOption) { RoutingOption.fromLabel(message.routingOption) }
    val msgType = remember(message.messageType) { MessageType.fromWireValue(message.messageType) }
    val timeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormatter.format(Date(message.timestamp)) }

    val bubbleColor = when {
        message.isError -> RecordingCrimsonContainer
        isUser -> CockpitSurfaceHighest
        else -> CockpitSurfaceElevated
    }
    val borderColor = when {
        message.isError -> RecordingCrimson.copy(alpha = 0.7f)
        isCurrentlySpeaking -> LeoCyan
        isUser -> LeoAmber.copy(alpha = 0.45f)
        else -> CockpitOutline
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chat_bubble_${message.id}"),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = if (isUser) 18.dp else 6.dp,
                topEnd = if (isUser) 6.dp else 18.dp,
                bottomStart = 18.dp,
                bottomEnd = 18.dp,
            ),
            border = BorderStroke(if (isCurrentlySpeaking) 1.5.dp else 1.dp, borderColor),
            modifier = Modifier.widthIn(min = 140.dp, max = 340.dp),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                // Header row: Sender + Routing chip + Message Type + Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (message.isError) {
                            Icon(
                                imageVector = Icons.Rounded.ErrorOutline,
                                contentDescription = "Error",
                                tint = RecordingCrimson,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                        Text(
                            text = if (isUser) "YOU" else "LEO",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                message.isError -> RecordingCrimson
                                isUser -> LeoAmber
                                else -> LeoCyan
                            },
                        )

                        RoutingBadge(routing = routing)

                        if (isUser) {
                            Icon(
                                imageVector = when (msgType) {
                                    MessageType.VOICE -> Icons.Rounded.Mic
                                    MessageType.FILE -> Icons.Rounded.AttachFile
                                    MessageType.TEXT -> Icons.Rounded.Keyboard
                                },
                                contentDescription = msgType.wireValue,
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp),
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                        )
                        if (!isUser) {
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = onReplaySpeech,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("replay_tts_${message.id}"),
                            ) {
                                Icon(
                                    imageVector = if (isCurrentlySpeaking) {
                                        Icons.Rounded.Stop
                                    } else {
                                        Icons.AutoMirrored.Rounded.VolumeUp
                                    },
                                    contentDescription = if (isCurrentlySpeaking) {
                                        stringResource(R.string.stop_speech_desc)
                                    } else {
                                        stringResource(R.string.replay_speech_desc)
                                    },
                                    tint = if (isCurrentlySpeaking) LeoCyan else TextSecondary,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }

                // Optional file preview
                if (!message.fileUrl.isNullOrBlank() && message.fileMimeType?.startsWith("image/") == true) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = Uri.parse(message.fileUrl),
                        contentDescription = message.fileName ?: "Attached image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp)),
                    )
                } else if (!message.fileName.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = CockpitSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CockpitOutline),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AttachFile,
                                contentDescription = null,
                                tint = LeoAmber,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = message.fileName,
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                )

                AnimatedVisibility(
                    visible = isCurrentlySpeaking,
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    Row(
                        modifier = Modifier.padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = LeoCyan,
                            modifier = Modifier.size(15.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Speaking aloud…",
                            style = MaterialTheme.typography.labelSmall,
                            color = LeoCyan,
                        )
                    }
                }

                if (showConfigureAction) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onOpenSettings,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LeoAmber,
                            contentColor = OnLeoAmber,
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text(
                            text = "Configure Webhook",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RoutingBadge(routing: RoutingOption, modifier: Modifier = Modifier) {
    val accent = routingColor(routing)
    Surface(
        modifier = modifier,
        color = accent.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
    ) {
        Text(
            text = routing.label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}

fun routingColor(option: RoutingOption): Color = when (option) {
    RoutingOption.ANIME -> RouteAnimeViolet
    RoutingOption.PHILOSOPHY -> RoutePhilosophyGold
    RoutingOption.CONTENT -> RouteContentCyan
    RoutingOption.GENERAL -> RouteGeneralSlate
}

@Composable
private fun LeoThinkingIndicator() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("leo_thinking_indicator"),
        horizontalArrangement = Arrangement.Start,
    ) {
        Surface(
            color = CockpitSurfaceElevated,
            shape = RoundedCornerShape(topStart = 6.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp),
            border = BorderStroke(1.dp, LeoCyan.copy(alpha = 0.5f)),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = LeoCyan,
                    strokeWidth = 2.dp,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.sending_to_leo),
                    style = MaterialTheme.typography.labelMedium,
                    color = LeoCyan,
                )
            }
        }
    }
}
