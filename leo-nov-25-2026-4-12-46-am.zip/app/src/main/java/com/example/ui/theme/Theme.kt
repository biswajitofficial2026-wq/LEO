package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val LeoDarkColorScheme = darkColorScheme(
    primary = LeoAmber,
    onPrimary = OnLeoAmber,
    primaryContainer = LeoAmberContainer,
    onPrimaryContainer = LeoAmber,
    secondary = LeoCyan,
    onSecondary = OnLeoCyan,
    secondaryContainer = LeoCyanContainer,
    onSecondaryContainer = LeoCyan,
    tertiary = ReadyEmerald,
    onTertiary = OnLeoCyan,
    tertiaryContainer = ReadyEmeraldContainer,
    onTertiaryContainer = ReadyEmerald,
    error = RecordingCrimson,
    onError = TextPrimary,
    errorContainer = RecordingCrimsonContainer,
    onErrorContainer = RecordingCrimson,
    background = CockpitObsidian,
    onBackground = TextPrimary,
    surface = CockpitSurface,
    onSurface = TextPrimary,
    surfaceVariant = CockpitSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = CockpitSurface,
    surfaceContainer = CockpitSurfaceElevated,
    surfaceContainerHigh = CockpitSurfaceHighest,
    outline = CockpitOutline,
    outlineVariant = CockpitOutlineBright,
)

private val LeoShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun LeoTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = LeoDarkColorScheme,
        typography = LeoTypography,
        shapes = LeoShapes,
        content = content,
    )
}
