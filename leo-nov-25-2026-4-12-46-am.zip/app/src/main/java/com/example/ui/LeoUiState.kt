package com.example.ui

import com.example.data.local.ChatMessageEntity
import com.example.data.model.RoutingOption

data class LeoUiState(
    val messages: List<ChatMessageEntity> = emptyList(),
    val webhookUrl: String = "",
    val selectedRouting: RoutingOption = RoutingOption.GENERAL,
    val draftText: String = "",
    val isRecording: Boolean = false,
    val isProcessingVoice: Boolean = false,
    val recordingDurationMs: Long = 0L,
    val partialTranscript: String = "",
    val voiceRms: Float = 0f,
    val isSending: Boolean = false,
    val isSpeaking: Boolean = false,
    val speakingMessageId: Long? = null,
    val isTtsReady: Boolean = false,
    val autoSpeakEnabled: Boolean = true,
    val speechRate: Float = 1.05f,
    val isSettingsOpen: Boolean = false,
    val isTestingWebhook: Boolean = false,
    val webhookTestResult: String? = null,
    val statusNotice: String? = null,
)
