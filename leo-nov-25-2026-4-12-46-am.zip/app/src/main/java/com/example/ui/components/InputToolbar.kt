package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.RoutingOption
import com.example.ui.theme.CockpitOutline
import com.example.ui.theme.CockpitOutlineBright
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceElevated
import com.example.ui.theme.CockpitSurfaceHighest
import com.example.ui.theme.LeoAmber
import com.example.ui.theme.OnLeoAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun InputToolbar(
    draftText: String,
    selectedRouting: RoutingOption,
    isSending: Boolean,
    onDraftTextChanged: (String) -> Unit,
    onSendText: () -> Unit,
    onAttachFile: () -> Unit,
    onRoutingSelected: (RoutingOption) -> Unit,
    modifier: Modifier = Modifier,
) {
    var dropdownExpanded by remember { mutableStateOf(false) }
    val routingAccent = routingColor(selectedRouting)

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = CockpitSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, CockpitOutline),
        tonalElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // 1. Standard Text Input Field (with inline Send button when text is entered)
            OutlinedTextField(
                value = draftText,
                onValueChange = onDraftTextChanged,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp, max = 96.dp)
                    .testTag("text_input_field"),
                placeholder = {
                    Text(
                        text = stringResource(R.string.message_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (draftText.isNotBlank() && !isSending) {
                            onSendText()
                        }
                    }
                ),
                trailingIcon = {
                    if (draftText.isNotBlank()) {
                        IconButton(
                            onClick = onSendText,
                            enabled = !isSending,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(LeoAmber)
                                .testTag("send_text_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = stringResource(R.string.send_message_desc),
                                tint = OnLeoAmber,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CockpitSurfaceElevated,
                    unfocusedContainerColor = CockpitSurfaceElevated,
                    focusedBorderColor = LeoAmber,
                    unfocusedBorderColor = CockpitOutline,
                    cursorColor = LeoAmber,
                ),
            )

            // 2. Paperclip Icon Button (native file picker for images/video/documents)
            Surface(
                onClick = onAttachFile,
                enabled = !isSending,
                color = CockpitSurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CockpitOutlineBright),
                modifier = Modifier
                    .size(48.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("attach_file_button"),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.AttachFile,
                        contentDescription = stringResource(R.string.attach_file_desc),
                        tint = TextPrimary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }

            // 3. Routing Dropdown Menu ("Anime", "Philosophy", "Content", "General")
            Box {
                Surface(
                    onClick = { dropdownExpanded = true },
                    color = CockpitSurfaceHighest,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, routingAccent.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("routing_dropdown_button"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(routingAccent),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedRouting.label,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            maxLines = 1,
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowDown,
                            contentDescription = stringResource(R.string.routing_mode_desc),
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }

                DropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false },
                    modifier = Modifier
                        .background(CockpitSurfaceHighest)
                        .testTag("routing_dropdown_menu"),
                ) {
                    RoutingOption.entries.forEach { option ->
                        val itemAccent = routingColor(option)
                        val isSelected = option == selectedRouting
                        DropdownMenuItem(
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(itemAccent),
                                    )
                                    Text(
                                        text = option.label,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) itemAccent else TextPrimary,
                                    )
                                }
                            },
                            trailingIcon = if (isSelected) {
                                {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = itemAccent,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            } else null,
                            onClick = {
                                dropdownExpanded = false
                                onRoutingSelected(option)
                            },
                            modifier = Modifier.testTag("routing_option_${option.label.lowercase()}"),
                        )
                    }
                }
            }
        }
    }
}
