package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.RoutingOption
import com.example.data.remote.WebhookClient
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches LEO`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LEO", appName)
    }

    @Test
    fun `routing options match expected four categories`() {
        assertEquals(
            listOf("Anime", "Philosophy", "Content", "General"),
            RoutingOption.entries.map { it.label },
        )
    }

    @Test
    fun `webhook response extraction handles object and array payloads`() {
        val client = WebhookClient()
        assertEquals(
            "Keep your eyes on the road.",
            client.extractTextFromResponse("""{"response":"Keep your eyes on the road."}"""),
        )
        assertEquals(
            "Stoicism teaches focus.",
            client.extractTextFromResponse("""[{"output":"Stoicism teaches focus."}]"""),
        )
        assertEquals(
            "Nested reply",
            client.extractTextFromResponse("""{"data":{"reply":"Nested reply"}}"""),
        )
    }
}
