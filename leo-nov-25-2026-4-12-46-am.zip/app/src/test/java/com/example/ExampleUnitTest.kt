package com.example

import com.example.data.model.RoutingOption
import com.example.data.remote.WebhookClient
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun routingOptionsMatchExpectedFourCategories() {
        assertEquals(
            listOf("Anime", "Philosophy", "Content", "General"),
            RoutingOption.entries.map { it.label },
        )
    }

    @Test
    fun webhookResponseExtractionHandlesObjectAndArrayPayloads() {
        val client = WebhookClient()
        assertEquals(
            "Keep your eyes on the road.",
            client.extractTextFromResponse("""{"response":"Keep your eyes on the road."}"""),
        )
        assertEquals(
            "Stoicism teaches focus.",
            client.extractTextFromResponse("""[{"output":"Stoicism teaches focus."}]"""),
        )
        assertEquals(
            "Nested reply",
            client.extractTextFromResponse("""{"data":{"reply":"Nested reply"}}"""),
        )
        assertEquals(
            "Plain text reply",
            client.extractTextFromResponse("Plain text reply"),
        )
    }
}
